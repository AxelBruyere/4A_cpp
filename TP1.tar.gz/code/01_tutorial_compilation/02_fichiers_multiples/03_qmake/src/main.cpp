
#include "lib1.hpp"

#include <iostream>
#include <string>


int main()
{
  std::cout<<"J'appelle ma fonction:"<<std::endl;
  ma_fonction();

  return 0;
}
