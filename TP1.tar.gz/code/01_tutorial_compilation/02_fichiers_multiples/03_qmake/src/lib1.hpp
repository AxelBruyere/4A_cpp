#pragma once

#ifndef LIB1_HPP
#define LIB1_HPP

void ma_fonction();

#endif