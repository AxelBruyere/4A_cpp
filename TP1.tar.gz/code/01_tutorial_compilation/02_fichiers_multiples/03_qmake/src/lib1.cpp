
#include "lib1.hpp"

#include <iostream>

using std::cout;
using std::endl;

void ma_fonction()
{
	auto T={7,8,9,-12};
	for(auto value : T)
		cout<<value<<endl;
}
