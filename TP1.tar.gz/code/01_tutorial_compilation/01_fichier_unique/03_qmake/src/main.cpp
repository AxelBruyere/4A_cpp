#include <iostream>
#include <string>

int main()
{
  std::string variable="Mon premier";
  variable += " programme.";

  std::cout<<variable<<std::endl;

  return 0;
}
